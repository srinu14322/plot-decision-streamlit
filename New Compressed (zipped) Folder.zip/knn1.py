import streamlit as st
import pandas as pd
from mlxtend.plotting import plot_decision_regions
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
import numpy as np

# Load datasets
ushape= pd.read_csv(r"C:\Users\SRINU\Downloads\Multiple CSV\Multiple CSV\1.ushape.csv",header=None,names=["f1","f2","cv"])
concentri1= pd.read_csv(r"C:\Users\SRINU\Downloads\Multiple CSV\Multiple CSV\2.concerticcir1.csv",header=None,names=["f1","f2","cv"])
concentri2= pd.read_csv(r"C:\Users\SRINU\Downloads\Multiple CSV\Multiple CSV\3.concertriccir2.csv",header=None,names=["f1","f2","cv"])
linearshape= pd.read_csv(r"C:\Users\SRINU\Downloads\Multiple CSV\Multiple CSV\4.linearsep.csv",header=None,names=["f1","f2","cv"])
outlier= pd.read_csv(r"C:\Users\SRINU\Downloads\Multiple CSV\Multiple CSV\5.outlier.csv",header=None,names=["f1","f2","cv"])
overlap= pd.read_csv(r"C:\Users\SRINU\Downloads\Multiple CSV\Multiple CSV\6.overlap.csv",header=None,names=["f1","f2","cv"])
xor= pd.read_csv(r"C:\Users\SRINU\Downloads\Multiple CSV\Multiple CSV\7.xor.csv",header=None,names=["f1","f2","cv"])
twospirals= pd.read_csv(r"C:\Users\SRINU\Downloads\Multiple CSV\Multiple CSV\8.twospirals.csv",header=None,names=["f1","f2","cv"])
random =pd.read_csv(r"C:\Users\SRINU\Downloads\Multiple CSV\Multiple CSV\9.random.csv",header=None,names=["f1","f2","cv"])


# Streamlit app layout
st.title("Decision surfaces")

with st.sidebar:
    st.title("Explorezone")
    radio_button = st.radio("Datasets", ["ushape","concentri1","concentri2",'linearshape','outlier','overlap','xor','twospirals','random'])
    k = st.slider("K value", min_value=1, max_value=15)
    radio_button2 = st.radio("Decision surfaces", ['single', 'Multiple'])

# Display selected dataset
if radio_button=='ushape':
    st.write(f"Displaying {radio_button} dataset")
    st.scatter_chart(data=ushape,x='f1',y='f2')
    fv=ushape.iloc[:,:2]
    cv=ushape.iloc[:,-1]
    std=StandardScaler()
    p_fv=std.fit_transform(fv)
    if (radio_button2=='single'):
        knn=KNeighborsClassifier(n_neighbors=k)
        knn.fit(p_fv,cv.astype(int))
        fig,ax=plt.subplots()
        plot_decision_regions(X=p_fv,y=cv.astype(int).values,clf=knn,ax=ax)
        st.pyplot(fig)
        st.write('{}NN'.format(k))
    elif(radio_button2=='Multiple'):
        fig, axes = plt.subplots(3, 2, figsize=(15, 15))

        for i, ax in zip(range(1, k, 2), axes.flatten()):
            knn = KNeighborsClassifier(n_neighbors=i)
            knn.fit(fv.values, cv.astype(int))
            plot_decision_regions(X=fv.values, y=cv.astype(int).values, clf=knn, ax=ax)
            ax.set_title(f'KNN with n_neighbors={i}')
        plt.tight_layout()
        st.pyplot(fig)
    x_train,x_test,y_train,y_test=train_test_split(fv,cv,test_size=0.2,random_state=1,stratify=cv)
    std=StandardScaler()
    px_train=std.fit_transform(x_train)
    px_test=std.transform(x_test)


    train_error=[]
    test_error=[]
    error=[]
    for i in range(1,k,2):
        knn=KNeighborsClassifier(n_neighbors=i)
        model=knn.fit(px_train,y_train)
        predicted_train=model.predict(px_train)
        train_error.append(1-accuracy_score(y_train,predicted_train))
        predicted_test=model.predict(px_test)
        test_error.append(1-accuracy_score(y_test,predicted_test))
    error={"Train Error":train_error,"Test Error":test_error}
    error_df=pd.DataFrame(error)
    st.line_chart(error_df)

if(radio_button=="concentri1"):
    st.write("concentri1")
    st.scatter_chart(data=concentri1,x='f1',y='f2')
    fv=concentri1.iloc[:,:2]
    cv=concentri1.iloc[:,-1]
    std=StandardScaler()
    p_fv=std.fit_transform(fv)
    if (radio_button2=='single'):
        knn=KNeighborsClassifier(n_neighbors=k)
        knn.fit(p_fv,cv.astype(int))
        fig,ax=plt.subplots()
        plot_decision_regions(X=p_fv,y=cv.astype(int).values,clf=knn,ax=ax)
        st.pyplot(fig)
        st.write('{}NN'.format(k))
    elif(radio_button2=='Multiple'):
        fig, axes = plt.subplots(3, 2, figsize=(15, 15))

        for i, ax in zip(range(1, k, 2), axes.flatten()):
            knn = KNeighborsClassifier(n_neighbors=i)
            knn.fit(fv.values, cv.astype(int))
            plot_decision_regions(X=fv.values, y=cv.astype(int).values, clf=knn, ax=ax)
            ax.set_title(f'KNN with n_neighbors={i}')
        plt.tight_layout()
        st.pyplot(fig)
    x_train,x_test,y_train,y_test=train_test_split(fv,cv,test_size=0.2,random_state=1,stratify=cv)
    std=StandardScaler()
    px_train=std.fit_transform(x_train)
    px_test=std.transform(x_test)


    train_error=[]
    test_error=[]
    error=[]
    for i in range(1,k,2):
        knn=KNeighborsClassifier(n_neighbors=i)
        model=knn.fit(px_train,y_train)
        predicted_train=model.predict(px_train)
        train_error.append(1-accuracy_score(y_train,predicted_train))
        predicted_test=model.predict(px_test)
        test_error.append(1-accuracy_score(y_test,predicted_test))
    error={"Train Error":train_error,"Test Error":test_error}
    error_df=pd.DataFrame(error)
    st.line_chart(error_df)



if(radio_button=="concentri2"):
    st.write("concentri2")
    st.scatter_chart(data=concentri2,x='f1',y='f2')
    fv=concentri2.iloc[:,:2]
    cv=concentri2.iloc[:,-1]
    std=StandardScaler()
    p_fv=std.fit_transform(fv)
    if (radio_button2=='single'):
        knn=KNeighborsClassifier(n_neighbors=k)
        knn.fit(p_fv,cv.astype(int))
        fig,ax=plt.subplots()
        plot_decision_regions(X=p_fv,y=cv.astype(int).values,clf=knn,ax=ax)
        st.pyplot(fig)
        st.write('{}NN'.format(k))
    elif(radio_button2=='Multiple'):
        fig, axes = plt.subplots(3, 2, figsize=(15, 15))

        for i, ax in zip(range(1, k, 2), axes.flatten()):
            knn = KNeighborsClassifier(n_neighbors=i)
            knn.fit(fv.values, cv.astype(int))
            plot_decision_regions(X=fv.values, y=cv.astype(int).values, clf=knn, ax=ax)
            ax.set_title(f'KNN with n_neighbors={i}')
        plt.tight_layout()
        st.pyplot(fig)
    x_train,x_test,y_train,y_test=train_test_split(fv,cv,test_size=0.2,random_state=1,stratify=cv)
    std=StandardScaler()
    px_train=std.fit_transform(x_train)
    px_test=std.transform(x_test)


    train_error=[]
    test_error=[]
    error=[]
    for i in range(1,k,2):
        knn=KNeighborsClassifier(n_neighbors=i)
        model=knn.fit(px_train,y_train)
        predicted_train=model.predict(px_train)
        train_error.append(1-accuracy_score(y_train,predicted_train))
        predicted_test=model.predict(px_test)
        test_error.append(1-accuracy_score(y_test,predicted_test))
    error={"Train Error":train_error,"Test Error":test_error}
    error_df=pd.DataFrame(error)
    st.line_chart(error_df)



if(radio_button=="linearshape"):
    st.write("linearshape")
    st.scatter_chart(data=linearshape,x='f1',y='f2')
    fv=linearshape.iloc[:,:2]
    cv=linearshape.iloc[:,-1]
    std=StandardScaler()
    p_fv=std.fit_transform(fv)
    if (radio_button2=='single'):
        knn=KNeighborsClassifier(n_neighbors=k)
        knn.fit(p_fv,cv.astype(int))
        fig,ax=plt.subplots()
        plot_decision_regions(X=p_fv,y=cv.astype(int).values,clf=knn,ax=ax)
        st.pyplot(fig)
        st.write('{}NN'.format(k))
    elif(radio_button2=='Multiple'):
        fig, axes = plt.subplots(3, 2, figsize=(15, 15))

        for i, ax in zip(range(1, k, 2), axes.flatten()):
            knn = KNeighborsClassifier(n_neighbors=i)
            knn.fit(fv.values, cv.astype(int))
            plot_decision_regions(X=fv.values, y=cv.astype(int).values, clf=knn, ax=ax)
            ax.set_title(f'KNN with n_neighbors={i}')
        plt.tight_layout()
        st.pyplot(fig)
    x_train,x_test,y_train,y_test=train_test_split(fv,cv,test_size=0.2,random_state=1,stratify=cv)
    std=StandardScaler()
    px_train=std.fit_transform(x_train)
    px_test=std.transform(x_test)


    train_error=[]
    test_error=[]
    error=[]
    for i in range(1,k,2):
        knn=KNeighborsClassifier(n_neighbors=i)
        model=knn.fit(px_train,y_train)
        predicted_train=model.predict(px_train)
        train_error.append(1-accuracy_score(y_train,predicted_train))
        predicted_test=model.predict(px_test)
        test_error.append(1-accuracy_score(y_test,predicted_test))
    error={"Train Error":train_error,"Test Error":test_error}
    error_df=pd.DataFrame(error)
    st.line_chart(error_df)





if(radio_button=="outlier"):
    st.write("outlier")
    st.scatter_chart(data=outlier,x='f1',y='f2')
    fv=outlier.iloc[:,:2]
    cv=outlier.iloc[:,-1]
    std=StandardScaler()
    p_fv=std.fit_transform(fv)
    if (radio_button2=='single'):
        knn=KNeighborsClassifier(n_neighbors=k)
        knn.fit(p_fv,cv.astype(int))
        fig,ax=plt.subplots()
        plot_decision_regions(X=p_fv,y=cv.astype(int).values,clf=knn,ax=ax)
        st.pyplot(fig)
        st.write('{}NN'.format(k))
    elif(radio_button2=='Multiple'):
        fig, axes = plt.subplots(3, 2, figsize=(15, 15))

        for i, ax in zip(range(1,k, 2), axes.flatten()):
            knn = KNeighborsClassifier(n_neighbors=i)
            knn.fit(fv.values, cv.astype(int))
            plot_decision_regions(X=fv.values, y=cv.astype(int).values, clf=knn, ax=ax)
            ax.set_title(f'KNN with n_neighbors={i}')
        plt.tight_layout()
        st.pyplot(fig)
    x_train,x_test,y_train,y_test=train_test_split(fv,cv,test_size=0.2,random_state=1,stratify=cv)
    std=StandardScaler()
    px_train=std.fit_transform(x_train)
    px_test=std.transform(x_test)


    train_error=[]
    test_error=[]
    error=[]
    for i in range(1,k,2):
        knn=KNeighborsClassifier(n_neighbors=i)
        model=knn.fit(px_train,y_train)
        predicted_train=model.predict(px_train)
        train_error.append(1-accuracy_score(y_train,predicted_train))
        predicted_test=model.predict(px_test)
        test_error.append(1-accuracy_score(y_test,predicted_test))
    error={"Train Error":train_error,"Test Error":test_error}
    error_df=pd.DataFrame(error)
    st.line_chart(error_df)





if(radio_button=="overlap"):
    st.write("overlap")
    st.scatter_chart(data=overlap,x='f1',y='f2')
    fv=overlap.iloc[:,:2]
    cv=overlap.iloc[:,-1]
    std=StandardScaler()
    p_fv=std.fit_transform(fv)
    if (radio_button2=='single'):
        knn=KNeighborsClassifier(n_neighbors=k)
        knn.fit(p_fv,cv.astype(int))
        fig,ax=plt.subplots()
        plot_decision_regions(X=p_fv,y=cv.astype(int).values,clf=knn,ax=ax)
        st.pyplot(fig)
        st.write('{}NN'.format(k))
    elif(radio_button2=='Multiple'):
        fig, axes = plt.subplots(3, 2, figsize=(15, 15))

        for i, ax in zip(range(1, k, 2), axes.flatten()):
            knn = KNeighborsClassifier(n_neighbors=i)
            knn.fit(fv.values, cv.astype(int))
            plot_decision_regions(X=fv.values, y=cv.astype(int).values, clf=knn, ax=ax)
            ax.set_title(f'KNN with n_neighbors={i}')
        plt.tight_layout()
        st.pyplot(fig)
    x_train,x_test,y_train,y_test=train_test_split(fv,cv,test_size=0.2,random_state=1,stratify=cv)
    std=StandardScaler()
    px_train=std.fit_transform(x_train)
    px_test=std.transform(x_test)


    train_error=[]
    test_error=[]
    error=[]
    for i in range(1,k,2):
        knn=KNeighborsClassifier(n_neighbors=i)
        model=knn.fit(px_train,y_train)
        predicted_train=model.predict(px_train)
        train_error.append(1-accuracy_score(y_train,predicted_train))
        predicted_test=model.predict(px_test)
        test_error.append(1-accuracy_score(y_test,predicted_test))
    error={"Train Error":train_error,"Test Error":test_error}
    error_df=pd.DataFrame(error)
    st.line_chart(error_df)





if(radio_button=="xor"):
    st.write("xor")
    st.scatter_chart(data=xor,x='f1',y='f2')
    fv=xor.iloc[:,:2]
    cv=xor.iloc[:,-1]
    std=StandardScaler()
    p_fv=std.fit_transform(fv)
    if (radio_button2=='single'):
        knn=KNeighborsClassifier(n_neighbors=k)
        knn.fit(p_fv,cv.astype(int))
        fig,ax=plt.subplots()
        plot_decision_regions(X=p_fv,y=cv.astype(int).values,clf=knn,ax=ax)
        st.pyplot(fig)
        st.write('{}NN'.format(k))
    elif(radio_button2=='Multiple'):
        fig, axes = plt.subplots(3, 2, figsize=(15, 15))

        for i, ax in zip(range(1, k, 2), axes.flatten()):
            knn = KNeighborsClassifier(n_neighbors=i)
            knn.fit(fv.values, cv.astype(int))
            plot_decision_regions(X=fv.values, y=cv.astype(int).values, clf=knn, ax=ax)
            ax.set_title(f'KNN with n_neighbors={i}')
        plt.tight_layout()
        st.pyplot(fig)
    x_train,x_test,y_train,y_test=train_test_split(fv,cv,test_size=0.2,random_state=1,stratify=cv)
    std=StandardScaler()
    px_train=std.fit_transform(x_train)
    px_test=std.transform(x_test)


    train_error=[]
    test_error=[]
    error=[]
    for i in range(1,k,2):
        knn=KNeighborsClassifier(n_neighbors=i)
        model=knn.fit(px_train,y_train)
        predicted_train=model.predict(px_train)
        train_error.append(1-accuracy_score(y_train,predicted_train))
        predicted_test=model.predict(px_test)
        test_error.append(1-accuracy_score(y_test,predicted_test))
    error={"Train Error":train_error,"Test Error":test_error}
    error_df=pd.DataFrame(error)
    st.line_chart(error_df)




if(radio_button=="twospirals"):
    st.write("twospirals")
    st.scatter_chart(data=twospirals,x='f1',y='f2')
    fv=twospirals.iloc[:,:2]
    cv=twospirals.iloc[:,-1]
    std=StandardScaler()
    p_fv=std.fit_transform(fv)
    if (radio_button2=='single'):
        knn=KNeighborsClassifier(n_neighbors=k)
        knn.fit(p_fv,cv.astype(int))
        fig,ax=plt.subplots()
        plot_decision_regions(X=p_fv,y=cv.astype(int).values,clf=knn,ax=ax)
        st.pyplot(fig)
        st.write('{}NN'.format(k))
    elif(radio_button2=='Multiple'):
        fig, axes = plt.subplots(3, 2, figsize=(15, 15))

        for i, ax in zip(range(1, k, 2), axes.flatten()):
            knn = KNeighborsClassifier(n_neighbors=i)
            knn.fit(fv.values, cv.astype(int))
            plot_decision_regions(X=fv.values, y=cv.astype(int).values, clf=knn, ax=ax)
            ax.set_title(f'KNN with n_neighbors={i}')
        plt.tight_layout()
        st.pyplot(fig)
    x_train,x_test,y_train,y_test=train_test_split(fv,cv,test_size=0.2,random_state=1,stratify=cv)
    std=StandardScaler()
    px_train=std.fit_transform(x_train)
    px_test=std.transform(x_test)


    train_error=[]
    test_error=[]
    error=[]
    for i in range(1,k,2):
        knn=KNeighborsClassifier(n_neighbors=i)
        model=knn.fit(px_train,y_train)
        predicted_train=model.predict(px_train)
        train_error.append(1-accuracy_score(y_train,predicted_train))
        predicted_test=model.predict(px_test)
        test_error.append(1-accuracy_score(y_test,predicted_test))
    error={"Train Error":train_error,"Test Error":test_error}
    error_df=pd.DataFrame(error)
    st.line_chart(error_df)




if(radio_button=="random"):
    st.write("random")
    st.scatter_chart(data=random,x='f1',y='f2')
    fv=random.iloc[:,:2]
    cv=random.iloc[:,-1]
    std=StandardScaler()
    p_fv=std.fit_transform(fv)
    if (radio_button2=='single'):
        knn=KNeighborsClassifier(n_neighbors=k)
        knn.fit(p_fv,cv.astype(int))
        fig,ax=plt.subplots()
        plot_decision_regions(X=p_fv,y=cv.astype(int).values,clf=knn,ax=ax)
        st.pyplot(fig)
        st.write('{}NN'.format(k))
    elif(radio_button2=='Multiple'):
        fig, axes = plt.subplots(3, 2, figsize=(15, 15))

        for i, ax in zip(range(1, k, 2), axes.flatten()):
            knn = KNeighborsClassifier(n_neighbors=i)
            knn.fit(fv.values, cv.astype(int))
            plot_decision_regions(X=fv.values, y=cv.astype(int).values, clf=knn, ax=ax)
            ax.set_title(f'KNN with n_neighbors={i}')
        plt.tight_layout()
        st.pyplot(fig)
    x_train,x_test,y_train,y_test=train_test_split(fv,cv,test_size=0.2,random_state=1,stratify=cv)
    std=StandardScaler()
    px_train=std.fit_transform(x_train)
    px_test=std.transform(x_test)


    train_error=[]
    test_error=[]
    error=[]
    for i in range(1,k,2):
        knn=KNeighborsClassifier(n_neighbors=i)
        model=knn.fit(px_train,y_train)
        predicted_train=model.predict(px_train)
        train_error.append(1-accuracy_score(y_train,predicted_train))
        predicted_test=model.predict(px_test)
        test_error.append(1-accuracy_score(y_test,predicted_test))
    error={"Train Error":train_error,"Test Error":test_error}
    error_df=pd.DataFrame(error)
    st.line_chart(error_df)